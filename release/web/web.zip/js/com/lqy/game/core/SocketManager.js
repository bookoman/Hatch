/*
* name;
*/
var SocketManager = /** @class */ (function () {
    function SocketManager() {
    }
    return SocketManager;
}());
//# sourceMappingURL=SocketManager.js.map