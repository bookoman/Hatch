/*
* 宠物品质评分配制表
*/
var QualityScoreSampleConfig = /** @class */ (function () {
    function QualityScoreSampleConfig() {
    }
    return QualityScoreSampleConfig;
}());
//# sourceMappingURL=QualityScoreSampleConfig.js.map