/*
* 宠物经验配制表
*/
var HeroLevelSampleVo = /** @class */ (function () {
    function HeroLevelSampleVo() {
    }
    return HeroLevelSampleVo;
}());
//# sourceMappingURL=HeroLevelSampleVo.js.map