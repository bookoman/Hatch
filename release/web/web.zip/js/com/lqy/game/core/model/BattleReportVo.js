/*
* 战斗数据管理
*/
var BattleReportVo = /** @class */ (function () {
    function BattleReportVo() {
    }
    return BattleReportVo;
}());
//# sourceMappingURL=BattleReportVo.js.map