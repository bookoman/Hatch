/*
* 服务器信息
*/
var ServerInfoVo = /** @class */ (function () {
    function ServerInfoVo() {
        this.name = "";
    }
    return ServerInfoVo;
}());
//# sourceMappingURL=ServerInfoVo.js.map