/*
* 关卡信息
*/
var GateInfoVo = /** @class */ (function () {
    function GateInfoVo() {
    }
    return GateInfoVo;
}());
//# sourceMappingURL=GateInfoVo.js.map