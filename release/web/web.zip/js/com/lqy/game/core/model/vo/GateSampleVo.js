/*
* 关卡地图配置表
*/
var GateSampleVo = /** @class */ (function () {
    function GateSampleVo() {
    }
    return GateSampleVo;
}());
//# sourceMappingURL=GateSampleVo.js.map