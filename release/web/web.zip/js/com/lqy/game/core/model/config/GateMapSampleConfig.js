/*
* 关卡地图配制表;
*/
var GateMapSampleConfig = /** @class */ (function () {
    function GateMapSampleConfig() {
    }
    return GateMapSampleConfig;
}());
//# sourceMappingURL=GateMapSampleConfig.js.map