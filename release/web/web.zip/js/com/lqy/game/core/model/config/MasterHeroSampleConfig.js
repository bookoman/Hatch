/*
* 怪物配置
*/
var MasterHeroSampleConfig = /** @class */ (function () {
    function MasterHeroSampleConfig() {
    }
    return MasterHeroSampleConfig;
}());
//# sourceMappingURL=MasterHeroSampleConfig.js.map