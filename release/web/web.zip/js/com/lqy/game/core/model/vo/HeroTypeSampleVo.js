/*
* 宠物物种配制表
*/
var HeroTypeSampleVo = /** @class */ (function () {
    function HeroTypeSampleVo() {
    }
    return HeroTypeSampleVo;
}());
//# sourceMappingURL=HeroTypeSampleVo.js.map