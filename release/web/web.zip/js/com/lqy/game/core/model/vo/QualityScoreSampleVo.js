/*
* 宠物品质评分配制表
*/
var QualityScoreSampleVo = /** @class */ (function () {
    function QualityScoreSampleVo() {
    }
    return QualityScoreSampleVo;
}());
//# sourceMappingURL=QualityScoreSampleVo.js.map