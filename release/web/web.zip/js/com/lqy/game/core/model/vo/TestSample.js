/*
* 测试xml数据
*/
var TestSample = /** @class */ (function () {
    function TestSample() {
    }
    return TestSample;
}());
//# sourceMappingURL=TestSample.js.map