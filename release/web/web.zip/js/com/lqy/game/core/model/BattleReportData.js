/*
* name;
*/
var BattleReportData = /** @class */ (function () {
    function BattleReportData() {
    }
    return BattleReportData;
}());
//# sourceMappingURL=BattleReportData.js.map