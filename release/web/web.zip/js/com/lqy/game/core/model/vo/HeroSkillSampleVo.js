/*
* 宠物技能配制表
*/
var HeroSkillSampleVo = /** @class */ (function () {
    function HeroSkillSampleVo() {
    }
    return HeroSkillSampleVo;
}());
//# sourceMappingURL=HeroSkillSampleVo.js.map