/*
* 关卡地图配制表;
*/
var GateMapSampleVo = /** @class */ (function () {
    function GateMapSampleVo() {
    }
    return GateMapSampleVo;
}());
//# sourceMappingURL=GateMapSampleVo.js.map