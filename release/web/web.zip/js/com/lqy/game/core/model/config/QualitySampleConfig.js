/*
* 宠物品质配制表
*/
var QualitySampleConfig = /** @class */ (function () {
    function QualitySampleConfig() {
    }
    return QualitySampleConfig;
}());
//# sourceMappingURL=QualitySampleConfig.js.map