/*
* name;
*/
var BaseScene = /** @class */ (function () {
    function BaseScene() {
    }
    BaseScene.prototype.enter = function () {
    };
    BaseScene.prototype.leave = function () {
    };
    return BaseScene;
}());
//# sourceMappingURL=BaseScene.js.map