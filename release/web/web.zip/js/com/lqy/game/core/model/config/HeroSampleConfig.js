/*
* 宠物配制表
*/
var HeroSampleConfig = /** @class */ (function () {
    function HeroSampleConfig() {
    }
    return HeroSampleConfig;
}());
//# sourceMappingURL=HeroSampleConfig.js.map