/*
* 宠物技能配制表
*/
var HeroSkillSampleConfig = /** @class */ (function () {
    function HeroSkillSampleConfig() {
    }
    return HeroSkillSampleConfig;
}());
//# sourceMappingURL=HeroSkillSampleConfig.js.map