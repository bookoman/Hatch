/*
* 阵型配置
*/
var LineupPosVo = /** @class */ (function () {
    function LineupPosVo() {
    }
    return LineupPosVo;
}());
//# sourceMappingURL=LineupPosVo.js.map