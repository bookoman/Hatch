/*
* 宠物物种配制表
*/
var HeroTypeSampleConfig = /** @class */ (function () {
    function HeroTypeSampleConfig() {
    }
    return HeroTypeSampleConfig;
}());
//# sourceMappingURL=HeroTypeSampleConfig.js.map