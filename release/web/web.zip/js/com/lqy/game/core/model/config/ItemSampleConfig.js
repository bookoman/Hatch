/*
* 物品配置表
*/
var ItemSampleConfig = /** @class */ (function () {
    function ItemSampleConfig() {
    }
    return ItemSampleConfig;
}());
//# sourceMappingURL=ItemSampleConfig.js.map