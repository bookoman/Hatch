/*
* 宠物配制表
*/
var HeroSampleVo = /** @class */ (function () {
    function HeroSampleVo() {
    }
    return HeroSampleVo;
}());
//# sourceMappingURL=HeroSampleVo.js.map