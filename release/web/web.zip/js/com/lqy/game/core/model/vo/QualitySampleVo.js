/*
* 宠物品质配制表
*/
var QualitySampleVo = /** @class */ (function () {
    function QualitySampleVo() {
    }
    return QualitySampleVo;
}());
//# sourceMappingURL=QualitySampleVo.js.map