/*
* 宠物经验配制表
*/
var HeroLevelSampleConfig = /** @class */ (function () {
    function HeroLevelSampleConfig() {
    }
    return HeroLevelSampleConfig;
}());
//# sourceMappingURL=HeroLevelSampleConfig.js.map