/*
* name;
*/
var TsJsContactUtile = /** @class */ (function () {
    function TsJsContactUtile() {
    }
    return TsJsContactUtile;
}());
//# sourceMappingURL=TsJsContactUtile.js.map