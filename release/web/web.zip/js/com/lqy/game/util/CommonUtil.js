/*
* name;
*/
var CommonUtil = /** @class */ (function () {
    function CommonUtil() {
    }
    return CommonUtil;
}());
//# sourceMappingURL=CommonUtil.js.map