/*
* name;
*/
var MapUtil = /** @class */ (function () {
    function MapUtil() {
    }
    MapUtil.TYPE_LOAD_NOCUT = 1;
    MapUtil.TYPE_LOAD_CUT = 2;
    return MapUtil;
}());
//# sourceMappingURL=MapUtil.js.map